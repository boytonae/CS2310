package graffiti_cloud;
import javax.swing.*;

import java.awt.*;
import java.util.List;
import java.util.*;
public class Canvas
{
    private static Canvas canvasSingleton;
    public static Canvas getCanvas()
    {
        if(canvasSingleton == null)
        {
            canvasSingleton = new Canvas("Graffiti Cloud", 800, 600, Color.white);
        }
        canvasSingleton.setVisible(true);
        return canvasSingleton;
    }
    private Integer width;
    private Integer height;
    private JFrame frame;
    private CanvasPane canvas;
    private Graphics2D graphic;
    private Color backgroundColor;
    private Image canvasImage;
    private List<Object> objects;
    private HashMap<Object, ShapeDescription> shapes;
    private Canvas(String title, int width, int height, Color bgColor)
    {
        this.width = width;
        this.height = height;
        frame = new JFrame();
        canvas = new CanvasPane();
        frame.setContentPane(canvas);
        frame.setTitle(title);
        canvas.setPreferredSize(new Dimension(width, height));
        backgroundColor = bgColor;
        frame.pack();
        Dimension size = canvas.getSize();
        canvasImage = canvas.createImage(size.width, size.height);
        graphic = (Graphics2D)canvasImage.getGraphics();
        graphic.setColor(backgroundColor);
        graphic.fillRect(0, 0, size.width, size.height);
        graphic.setColor(Color.black);
        objects = new ArrayList<Object>();
        shapes = new HashMap<Object, ShapeDescription>();
    }
    public void setVisible(boolean visible)
    {
        frame.setVisible(visible);
    }
    public Integer getWidth()
    {
        return this.width;
    }
    public Integer getHeight()
    {
        return this.height;
    }
    public Integer getTextWidth(Font f, String text)
    {
        return (new Double(f.getStringBounds(text,graphic.getFontRenderContext()).getWidth())).intValue();
    }
    public Integer getTextHeight(Font f, String text)
    {
        return (new Double(f.getStringBounds(text,graphic.getFontRenderContext()).getHeight())).intValue();
    }
    public void draw(Object referenceObject, String color, Shape shape)
    {
        objects.remove(referenceObject);
        objects.add(referenceObject);
        shapes.put(referenceObject, new ShapeDescription(shape, color));
        redraw();
    }
    public void draw(Object referenceObject, String color)
    {
        objects.remove(referenceObject);
        objects.add(referenceObject);
        shapes.put(referenceObject, new ShapeDescription((Text) referenceObject, color));
        redraw();
    }
    public void erase(Object referenceObject)
    {
        objects.remove(referenceObject);
        shapes.remove(referenceObject);
        redraw();
    }
    public void clearCanvas()
    {
        objects.clear();
        shapes.clear();
        redraw();
    }
    public void setForegroundColor(String colorString)
    {
        if(colorString.equals("red"))
        {
            graphic.setColor(Color.red);
        }
        else if(colorString.equals("black"))
        {
            graphic.setColor(Color.black);
        }
        else if(colorString.equals("blue"))
        {
            graphic.setColor(Color.blue);
        }
        else if(colorString.equals("yellow"))
        {
            graphic.setColor(Color.yellow);
        }
        else if(colorString.equals("green"))
        {
            graphic.setColor(Color.green);
        }
        else if(colorString.equals("magenta"))
        {
            graphic.setColor(Color.magenta);
        }
        else if(colorString.equals("white"))
        {
            graphic.setColor(Color.white);
        }
        else if(colorString.equals("pink"))
        {
            graphic.setColor(Color.pink);
        }
        else if(colorString.equals("orange"))
        {
            graphic.setColor(Color.orange);
        }
        else if(colorString.equals("cyan"))
        {
            graphic.setColor(Color.cyan);
        }
        else
        {
            graphic.setColor(Color.black);
        }
    }
    public void wait(int milliseconds)
    {
        try
        {
            Thread.sleep(milliseconds);
        } 
        catch (Exception e)
        {
            
        }
    }
    private void redraw()
    {
        erase();
        for(Object shape : objects)
        {
            shapes.get(shape).draw(graphic);
        }
        canvas.repaint();
    }
    private void erase()
    {
        Color original = graphic.getColor();
        graphic.setColor(backgroundColor);
        Dimension size = canvas.getSize();
        graphic.fill(new java.awt.Rectangle(0, 0, size.width, size.height));
        graphic.setColor(original);
    }
    @SuppressWarnings("serial")
	private class CanvasPane extends JPanel
    {
        public void paint(Graphics g)
        {
            g.drawImage(canvasImage, 0, 0, null);
        }
    }
    private class ShapeDescription
    {
        private Shape shape;
        private String colorString;
        private Text txt;
        public ShapeDescription(Shape shape, String color)
        {
            this.shape = shape;
            colorString = color;
            this.txt = null;
        }
        public ShapeDescription(Text txt, String color)
        {
            this.shape = null;
            colorString = color;
            this.txt = txt;
        }
        public void draw(Graphics2D graphic)
        {
            setForegroundColor(colorString);
            if (shape != null)
            {
                graphic.fill(shape);
            }
            else
            {
                Font f = new Font(txt.getFontName(), Font.PLAIN, txt.getFontSize());
                graphic.setFont(f);
                graphic.drawString(txt.getText(), txt.getXPosition(), txt.getYPosition());
            }
        }
    }
}