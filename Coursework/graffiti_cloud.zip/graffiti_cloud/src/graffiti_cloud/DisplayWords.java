package graffiti_cloud;
import java.util.ArrayList;
import java.util.Random;
import java.lang.Math;
public class DisplayWords
{
    private int canvas_width;
    private int canvas_height;
    private int cx;
    private int cy;
    private int colour;
    private int start_size;
    private boolean is_multi_colour;
    private final String[] colors = {"red", "yellow", "blue", "green", "magenta", "pink", "orange", "cyan", "black"};
    private String strategy;
    @SuppressWarnings("unused")
	private String[] legal_strategies = {"random", "inside_out", "outside_in", "in_line"};
    public DisplayWords()
    {
        canvas_width = Canvas.getCanvas().getWidth();
        canvas_height = Canvas.getCanvas().getHeight();
        cx = canvas_width / 2;
        cy = canvas_height / 2;
        colour = 0;
        start_size = 0;
        is_multi_colour = true;
        strategy = "random";
    }
    public void show_percentage(ArrayList <WordCount> words, int pc)
    {
        int num_words = 0;
        if (pc > 0 && pc <= 100)
        {
            num_words = (int)(((double)words.size() / 100.0) * (double)pc);
        }
        for (int i = 0; i < num_words; i++)
        {
            if (i > 0)
            {
                display_word(words.get(i).get_text(), words.get(i - 1).get_text(), words.get(i).get_count(), i);
            }
            else
            {
                display_word(words.get(i).get_text(), null, words.get(i).get_count(), i);
            }
            if (colour < 8)
            {
                colour++;
            }
            else
            {
                colour = 0;
            }
        }
    }
    public void erase_words(ArrayList <WordCount> words)
    {
        for (WordCount i : words)
        {
            i.get_text().makeInvisible();
        }
    }
    public void set_multi_colour(boolean multi_colour)
    {
        is_multi_colour = multi_colour;
    }
    public void set_strategy(String strategy)
    {
        this.strategy = strategy;
    }
    private void display_word(Text word, Text previous_word, int count, int position)
    {
        if (position == 0)
        {
            word.changeSize(count + 9);
            start_size = word.getFontSize();
        }
        if (strategy == "random")
        {
            word.changeSize(count + 9);
            if (is_multi_colour)
            {
                word.changeColor(colors[colour]);
            }
            word.randomizePosition();
            word.makeVisible();
        }
        else if (strategy == "in_line")
        {
            word.changeSize(count + 9);
            if (is_multi_colour)
            {
                word.changeColor(colors[colour]);
            }
            if (previous_word != null)
            {
                word.positionOnCanvas(previous_word.getXPosition() + previous_word.getTextWidth() + 1, previous_word.getYPosition());
                if (word.getXPosition() > (canvas_width - 4 - word.getTextWidth()))
                {
                    word.moveHorizontal(-word.getXPosition());
                    word.moveVertical(start_size);
                    start_size = word.getFontSize();
                }
            }
            else
            {
                word.positionOnCanvas(0, 0);
            }
            word.makeVisible();
        }
        else if (strategy == "outside_in")
        {
            Random random = new Random();
            word.changeSize(count + 9);
            int distance = word.getFontSize() - 10;
            double angle = random.nextDouble() * Math.PI * 2;
            if (is_multi_colour)
            {
                word.changeColor(colors[colour]);
            }
            word.positionOnCanvas(cx, cy);
            word.moveHorizontal((int)(distance * 8 * Math.sin(Math.toDegrees(angle))));
            word.moveVertical((int)(distance * 8 * Math.cos(Math.toDegrees(angle))));
            word.makeVisible();
            if (word.getXPosition() < 0)
            {
                word.moveHorizontal(-word.getXPosition());
            }
            if (word.getXPosition() + word.getTextWidth() > canvas_width)
            {
                word.moveHorizontal(canvas_width - word.getXPosition() - word.getTextWidth());
            }
            if (word.getYPosition() < 0)
            {
                word.moveVertical(-word.getYPosition());
            }
            if (word.getYPosition() + word.getTextHeight() > canvas_height)
            {
                word.moveVertical(canvas_height - word.getYPosition() - word.getTextHeight());
            }
        }
    }
}