package graffiti_cloud;
public class Main
{
    private static WordCollector wordcollector;
    public static void main(String[] args)
    {
        wordcollector = new WordCollector();
        wordcollector.print_report();
        wordcollector.set_multi_colour();
        wordcollector.set_strategy("outside_in");
        wordcollector.generate_display(10);
    }
}