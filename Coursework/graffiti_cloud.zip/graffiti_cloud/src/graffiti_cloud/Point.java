package graffiti_cloud;
import java.util.Random;
public class Point
{
    private int xCoordinate;
    private int yCoordinate;
    public Point()
    {
        Random randomGenerator = new Random();
        xCoordinate = randomGenerator.nextInt(Canvas.getCanvas().getWidth());
        yCoordinate = randomGenerator.nextInt(Canvas.getCanvas().getHeight());
    }
    public Point(int x, int y)
    {
        xCoordinate = x;
        yCoordinate = y;
    }
    public int getX()
    {
        return xCoordinate;
    }
    public int getY()
    {
        return yCoordinate;
    }
    public void setX(Integer x)
    {
        xCoordinate = x;
    }
    public void setY(Integer y)
    {
        yCoordinate = y;
    }
}