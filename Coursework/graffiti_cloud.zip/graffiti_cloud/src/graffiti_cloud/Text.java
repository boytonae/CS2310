package graffiti_cloud;
import java.awt.GraphicsEnvironment;
import java.awt.GraphicsConfiguration;
import java.awt.Font;
@SuppressWarnings("unused")
public class Text
{
    private int leftX, leftY;
    private String text;
    private int fontSize;
    private String color;
    private String fontName;
    private boolean isVisible;
    private Font font;
    public Text(String text)
    {
        this.text = text;
        leftX = 50;
        leftY = 100;
        fontSize = 12;
        color = "black";
        fontName = "Arial";
        isVisible = false;
        setFont();
    }
    private void setFont()
    {
        font = new Font(fontName, Font.PLAIN, fontSize);
    }
    public void makeVisible()
    {
        isVisible = true;
        draw();
    }
    public void makeInvisible()
    {
        erase();
        isVisible = false;
    }
    public void moveRight()
    {
        moveHorizontal(20);
    }
    public void moveLeft()
    {
        moveHorizontal(-20);
    }
    public void moveUp()
    {
        moveVertical(-20);
    }
    public void moveDown()
    {
        moveVertical(20);
    }
    public void moveHorizontal(int distance)
    {
        erase();
        leftX = leftX + distance;
        draw();
    }
    public void moveVertical(int distance)
    {
        erase();
        leftY = leftY + distance;
        draw();
    }
    public void slowMoveHorizontal(int distance)
    {
        int delta;
        if (distance < 0) 
        {
            delta = -1;
            distance = -distance;
        }
        else 
        {
            delta = 1;
        }
        for (int i = 0; i < distance; i++)
        {
            leftX += delta;
            draw();
        }
    }
    public void slowMoveVertical(int distance)
    {
        int delta;
        if (distance < 0) 
        {
            delta = -1;
            distance = -distance;
        }
        else 
        {
            delta = 1;
        }
        for (int i = 0; i < distance; i++)
        {
            leftY += delta;
            draw();
        }
    }
    public void changeSize(int newSize)
    {
        erase();
        fontSize = newSize;
        setFont();
        draw();
    }
    public void changeColor(String newColor)
    {
        color = newColor;
        draw();
    }
    public void printFonts()
    {
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        String[] names = ge.getAvailableFontFamilyNames();
        for (String name : names)
        {
            System.out.println(name);
        }
    }
    public void changeFont(String newFontName)
    {
        fontName = newFontName;
        setFont();
        draw();
    }
    public int getXPosition()
    {
        return leftX;
    }
    public int getYPosition()
    {
        return leftY;
    }
    public int getFontSize()
    {
        return fontSize;
    }
    public String getText()
    {
        return text;
    }
    public String getFontName()
    {
        return fontName;
    }
    public void setPosition(int xPos, int yPos)
    {
        Point p = new Point(xPos, yPos);
        erase();
        leftX = p.getX();
        leftY = p.getY();
        draw();
    }
    public void randomizePosition()
    {
        Point p = new Point();
        positionOnCanvas(p.getX(), p.getY());
    }
    public void positionOnCanvas(int x, int y)
    {
        Canvas c = Canvas.getCanvas();
        if (x < 0) x = 0;
        if (y-this.getTextHeight() < 0) y = this.getTextHeight();
        if (c.getTextWidth(font, text) < c.getWidth())
        {
            int rightX = x + c.getTextWidth(font, text);
            if (rightX > c.getWidth())
            {
                x = (x - (rightX - c.getWidth()));
            }
        }
        if (c.getTextHeight(font, text) < c.getHeight())
        {
            if (y > c.getHeight())
            {
                y = c.getHeight();
            }
        }
        this.setPosition(x, y);
    }
    public int getTextWidth()
    {
        Canvas c = Canvas.getCanvas();
        return c.getTextWidth(font, text);
    }
    public int getTextHeight()
    {
        Canvas c = Canvas.getCanvas();
        return c.getTextHeight(font, text);
    }
    private void draw()
    {
        if(isVisible)
        {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color);
            canvas.wait(10);
        }
    }
    private void erase()
    {
        if(isVisible)
        {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
}