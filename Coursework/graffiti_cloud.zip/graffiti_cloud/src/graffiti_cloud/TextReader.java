package graffiti_cloud;
import java.io.*;
import java.util.Scanner;
import java.util.Set;
import java.util.HashSet;
public class TextReader
{
    @SuppressWarnings("unused")
	private String file;
    private Scanner s;
    private Set<String> stopWords;
    public TextReader(String file)
    {
        stopWords = new HashSet<String>();
        try
        {
            initialiseStopWords();
            s = new Scanner(new BufferedReader(new FileReader(file)));
            s.useDelimiter("[^a-zA-Z0-9]+");
        }
        catch (FileNotFoundException e)
        {
            System.err.println(e.getMessage());
            System.exit(1);
        }
    }
    private void initialiseStopWords() throws FileNotFoundException
    {
        @SuppressWarnings("resource")
		Scanner s = new Scanner(new BufferedReader(new FileReader("assets/txt/stop_words.txt")));
        s.useDelimiter(",");
        while (s.hasNext())
        {
            stopWords.add(s.next());
        }
    }
    public String readNextWord()
    {
        while (s.hasNext())
        {
            String word = s.next().toLowerCase();
            if (!stopWords.contains(word) && word.length() > 1)
            {
                return word;
            }
        }
        return null;
    }
}