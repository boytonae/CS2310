package graffiti_cloud;
public class WordCount implements Comparable<WordCount>
{
    private int count;
    private Text word;
    public WordCount(String word)
    {
        count = 1;
        this.word = new Text(word);
    }
    public int compareTo(WordCount wc)
    {
        if (count < wc.get_count())
        {
            return 1;
        }
        else if (count > wc.get_count())
        {
            return -1;
        }
        else
        {
            return 0;
        }
    }
    public void increment_count()
    {
        count++;
    }
    public int get_count()
    {
        return count;
    }
    public Text get_text()
    {
        return word;
    }
}