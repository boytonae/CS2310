package graffiti_cloud;
import java.util.ArrayList;
import java.util.Collections;
public class WordCollector
{
    private TextReader textreader;
    private DisplayWords display;
    private ArrayList<WordCount> words;
    private int num_words;
    public WordCollector()
    {
        textreader = new TextReader("assets/txt/input.txt");
        words = new ArrayList<WordCount>();
        display = new DisplayWords();
        num_words = 0;
        read();
    }
    public void print_report()
    {
        System.out.println("There are a total of " + num_words + " different words.");
        for (WordCount i : words)
        {
            System.out.println(i.get_text().getText() + " appeared " + i.get_count() + " times.");
        }
    }
    public void generate_display(int percentage)
    {
        display.show_percentage(words, percentage);
    }
    public void erase_words()
    {
        display.erase_words(words);
    }
    public void set_multi_colour()
    {
        display.set_multi_colour(true);
    }
    public void set_monochrome()
    {
        display.set_multi_colour(false);
    }
    public void set_strategy(String strategy)
    {
        display.set_strategy(strategy);
    }
    private void read()
    {
        String nextword = textreader.readNextWord();
        while (nextword != null)
        {
            if (find(nextword) != null)
            {
                find(nextword).increment_count();
            }
            else
            {
                WordCount word = new WordCount(nextword);
                words.add(word);
            }
            num_words++;
            nextword = textreader.readNextWord();
        }
        Collections.sort(words);
    }
    private WordCount find(String word)
    {
        for (WordCount i : words)
        {
            if (i.get_text().getText().equals(word))
            {
                return i;
            }
        }
        return null;
    }
}